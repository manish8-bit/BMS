package com.my.bookmyshow.dtos;

public enum ResponseStatus {
    SUCCESS,
    FALIURE
}
