package com.my.bookmyshow.models;

public enum PaymentStatus {
    SUCCESS,
    FAILURE,
    REFUND
}
