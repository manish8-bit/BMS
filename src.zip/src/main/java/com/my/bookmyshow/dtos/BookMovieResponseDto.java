package com.my.bookmyshow.dtos;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class BookMovieResponseDto {
    private int amount;
    private long bookingId;
    private ResponseStatus responseStatus;
}
