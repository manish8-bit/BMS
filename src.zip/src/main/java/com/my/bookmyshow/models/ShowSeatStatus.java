package com.my.bookmyshow.models;

public enum ShowSeatStatus {
    AVAILABLE,
    UNAVAILABLE,
    BOOKED,
    BLOCKED
}
