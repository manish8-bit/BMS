package com.my.bookmyshow.models;

public enum BookingStatus  {
    CONFIRMED,
    CANCELLED,
    PENDING
}
