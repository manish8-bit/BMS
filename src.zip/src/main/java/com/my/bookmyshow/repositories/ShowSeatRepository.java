package com.my.bookmyshow.repositories;

import com.my.bookmyshow.models.ShowSeat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;

public interface ShowSeatRepository extends JpaRepository<ShowSeat, Long> {
    @Override
    List <ShowSeat> findAllById(Iterable <Long> aLong);
}
