package com.my.bookmyshow.models;

public enum Feature {
    THREE_D,
    TWO_D,
    DOLBY,
    HD,
    DOLBY_AUDIO
}
