package com.my.bookmyshow.services;

import com.my.bookmyshow.models.Show;
import com.my.bookmyshow.models.ShowSeat;
import com.my.bookmyshow.models.User;
import com.my.bookmyshow.models.Booking;
import com.my.bookmyshow.repositories.ShowRepository;
import com.my.bookmyshow.repositories.ShowSeatRepository;
import com.my.bookmyshow.repositories.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.transaction.annotation.Isolation;



import java.util.List;
import java.util.Optional;

@Service
public class BookingService {
    private UserRepository userRepository;  // DI to get this via spring boot
    private ShowRepository showRepository;
    private ShowSeatRepository showSeatRepository;
    @Transactional(isolation = Isolation.SERIALIZABLE)
    // this method is called once user has selected the seat and pressed confirm
    public Booking bookMovie(Long userId, List<Long> seatIds, Long showId){
        /* this is the confirmation page
        ------- start lock here ----- todays soln
        1. get the user from user id
        2. get the show from show id
        ------- take a lock---------// ideal soln
        3. get the show seats from seat ids
        4. check if seats are available
        5. if yes, make status as blocked or Booking in progress
        ------- relase the lock------- // ideal sol
        6. save updated show seats in DB and end lock
         ------- end lock here ----- todays soln
         */
        // this method returns confirmation of seats and 15 min timer has started for payment
        Optional<User> userOptional = userRepository.findById(userId);
        if(userOptional.isEmpty()){
            throw new RuntimeException();
        }
        User bookedBy= userOptional.get();
        Optional<Show> showOptional = showRepository.findById(showId);
        if(showOptional.isEmpty()){
            throw new RuntimeException();
        }
        Show bookedShow = showOptional.get();
        List<ShowSeat> showSeats = showSeatRepository.findAllById(seatIds);
        return null;
    }
}
