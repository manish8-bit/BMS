package com.my.bookmyshow.models;

public enum PaymentProvider {

    PAYU,
    RAZORPAY
}
