package com.my.bookmyshow.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;
@Getter
@Setter
@Entity

public class Booking extends BaseModel{
    @Enumerated(EnumType.ORDINAL)
    private BookingStatus bookingStatus;
//    @ManyToMany
//    private List<ShowSeat> showSeats; // as many to many a mappping table will be created
    @ManyToMany
    @JoinTable(
        name = "booking_show_seat",
        joinColumns = @JoinColumn(name = "booking_id"),
        inverseJoinColumns = @JoinColumn(name = "show_seat_id")
    )
    private List<ShowSeat> showSeats;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private User user;
    private Date bookedAt;
    @ManyToOne
    private  Show show;
    private int amount;
    @OneToMany
    private  List<Payment> payments;
}
