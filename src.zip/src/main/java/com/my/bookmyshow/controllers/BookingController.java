package com.my.bookmyshow.controllers;

import com.my.bookmyshow.dtos.BookMovieRequestDto;
import com.my.bookmyshow.dtos.BookMovieResponseDto;
import com.my.bookmyshow.services.BookingService;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

@Controller
public class BookingController {
    private BookingService bookingService;
    public BookMovieResponseDto bookMovie(BookMovieRequestDto bookMovieRequestDto, BookMovieResponseDto bookMovieResponseDto){
        return null;
    }
}
